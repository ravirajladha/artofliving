@include('inc.header')
<?php $priviliges = session('rexkod_apex_user_priviliges');
$user_priviliges = explode(',',$priviliges);  ?>

<link rel="stylesheet" type="text/css" href="/assets/css/vendors/datatables.css">

<div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-12 col-sm-6">
                  <h3>Locations</h3>
                </div>
                <div class="col-12 col-sm-6">
                  <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="/index"> <i data-feather="home"></i> Home</a></li>
                        <li class="breadcrumb-item active"><a href="#">All Locations</a></li>

                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid general-widget">
            <div class="row">


            <div class="container-fluid card">
            <div class="row card-body">
                    <table class="display table table-bordernone" id="basic-1">
                        <thead>
                          <tr>
                            <th>ID</th>
                            <th>Type</th>
                            <th>Location Name</th>
                            <th>Address</th>
                            <th>Lat Lon</th>
                            <?php if(in_array(7, $user_priviliges)) {?>

                            <th>Action</th>
                        <?php } ?>

                          </tr>
                        </thead>
                        <tbody>
                        <?php foreach($data['locations'] as $location){

                          ?>
                          <tr>
                            <td><?php echo $location->id; ?></td>
                            <td><?php echo $location->type; ?></td>
                            <td><?php echo $location->name; ?></td>
                            <td><?php echo $location->address; ?></td>
                            <td><?php echo $location->latlon; ?></td>

                            <?php if(in_array(7, $user_priviliges)) {?>
                            <td><a href="/edit_location/<?php echo $location->id; ?>"><button style="font-size:12px;padding:2px 5px" class="btn btn-xs btn-info"><i class='fa fa-pencil'></i></button></a></td>
                            <?php } ?>


                          </tr>
                        <?php } ?>

                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>


        @include('inc.footer')


<script src="/assets/js/datatable/datatables/jquery.dataTables.min.js"></script>
    <script src="/assets/js/datatable/datatables/datatable.custom.js"></script>
