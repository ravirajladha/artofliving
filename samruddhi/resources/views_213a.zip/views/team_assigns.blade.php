<?php

namespace App\Http\Controllers;
use App\Models\Auth;
use App\Models\Assets;
?>
@include('inc.header')

<link rel="stylesheet" type="text/css" href="/assets/css/vendors/datatables.css">
     
<div class="page-body">
          <div class="container-fluid">
            <div class="page-title">
              <div class="row">
                <div class="col-12 col-sm-6">
                  <h3>Team Assigns</h3>
                </div>
                <div class="col-12 col-sm-6">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/pages/index">                                      
                      <i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item">Team</li>
                  
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <!-- Container-fluid starts-->
          <div class="container-fluid general-widget">
            <div class="row">
                
        
              <div class="col-xl-12 col-md-12 dash-xl-100 dash-lg-100 dash-39">
                <div class="card ongoing-request recent-orders">
                  <br>
                  <div class="card-body pt-0">
                    <div class="table-responsive">
                    <table class="display" id="basic-1">
                        <thead>
                          <tr>
                          <th>ID</th>
                          <th>User</th>
                            <th>Asset</th>
                            <th>Datetime</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php 
                         foreach($data['notifications'] as $notification){ 
                         $user = Auth::where('id',$notification->user_id)->first();
                        
                         $asset = Assets::where('id',$notification->asset_id)->first();
                        
                        ?>
                          <tr>
                          <td><?php echo $notification->id; ?></td>
                           <td><?php echo $user->name; ?></td>
                            <td><?php echo $asset->name; ?></td>
                            <td><?php echo date('M jS Y - h:m A', strtotime($notification->datetime)); ?></td>
                            <td>
                                <?php 
                                if($notification->type == "assign" && $notification->status == "0"){ ?>
                                    <a href="/assign_response/<?php echo $notification->id; ?>/<?php echo $notification->asset_id; ?>/1"><button class="btn btn-sm btn-success" style="padding:3px;font-size:11px">Accept</button></a>
                                    <a href="/assign_response/<?php echo $notification->id; ?>/<?php echo $notification->asset_id; ?>/3"><button class="btn btn-sm btn-warning" style="padding:3px;font-size:11px">Reject</button></a>
                                <?php } ?>
                            </td>
                           

                            
                          </tr>
                        <?php } ?>
                         
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
          
            </div>
          </div>
          <!-- Container-fluid Ends-->
        </div>
  

@include('inc.footer')


<script src="/assets/js/datatable/datatables/jquery.dataTables.min.js"></script>
    <script src="/assets/js/datatable/datatables/datatable.custom.js"></script>