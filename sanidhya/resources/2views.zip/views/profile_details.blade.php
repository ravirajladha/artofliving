@include("inc_sanidhya.header")

<link rel="stylesheet" type="text/css" href="/assets/css/vendors/datatables.css">

<div class="page-body">
  <div class="container-fluid">
    <div class="page-title">
      <div class="row">
        <div class="col-12 col-sm-6">
          <h3>User Profile Details</h3>
        </div>
        <div class="col-12 col-sm-6">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html"> <i data-feather="home"></i></a></li>
            <li class="breadcrumb-item">Home</li>
            <li class="breadcrumb-item active">Events</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
  <!-- Container-fluid starts-->
  <?php


use App\Models\Profile;

  $url =  "{$_SERVER['REQUEST_URI']}";
  $url = explode('/', $url);
  ?>
  <div class="container-fluid general-widget">
    <div class="row">
        <?php 
             $data= Profile::all();
        ?>

      <div class="col-xl-12 col-md-12 dash-xl-100 dash-lg-100 dash-39">
        <div class="card ongoing-project recent-orders">
          <br>
          <div class="card-body pt-0">
            <div class="table-responsive">
              <table class="display" id="basic-1">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>User Type</th>
                    <th>First name </th>
                    <th >Last name</th>
                    <th>Phone no</th>
                    <th>Email ID</th>
                    <th>PAN</th>
                    <th>Aadhaar</th>
                    <th>State</th>
                    <th>City</th>
                    <th>Company name</th>
                    <th>Company PAN</th>
                    <th>Company state</th>
                  </tr>
                </thead>
                <tbody>
            
                   @foreach($data as $datas)
                    <tr>

                      <td style="padding:0 20px">{{$datas->id}}</td>
                      <td style="padding:0 20px">{{$datas->type}}</td>
                      <td style="padding:0 20px">{{$datas->first_name}}</td>
                      <td style="padding:0 20px">{{$datas->last_name}}</td>
                      <td style="padding:0 20px">{{$datas->phone}}</td>
                      <td>{{$datas->email}}</td>
                      <td>{{$datas->pan}}</td>
                      <td>{{$datas->aadhaar}}</td>
                      <td>{{$datas->state}}</td>
                      <td>{{$datas->city}}</td>
                      <th>{{$datas->company_name	}}</th>
                    <th>{{$datas->company_pan}}</th>
                    <th>{{$datas->company_state}}</th>
     
                      
              @endforeach
                        

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
@include("inc_sanidhya.footer")


<script src="/assets/js/datatable/datatables/jquery.dataTables.min.js"></script>
<script src="/assets/js/datatable/datatables/datatable.custom.js"></script>


<script>
  function copy(that) {
    var inp = document.createElement('input');
    document.body.appendChild(inp)
    inp.value = that.textContent
    inp.select();
    document.execCommand('copy', false);
    inp.remove();
  }
</script>