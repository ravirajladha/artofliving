<div class="alert alert-success alert-dismissible fade" role="alert">
    <strong>Payment Has been Successfully Received</strong>
</div>
<a href="{{route('paytm.purchase')}}">Check the demo again</a>