<div id="reader" style="width:600px"></div>
<div id="result"></div>


  
