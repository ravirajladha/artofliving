<div class="alert alert-success alert-dismissible fade" role="alert">
    <strong>Your Payment Has been failed</strong>
</div>
<a href="{{route('paytm.purchase')}}">Check the demo again</a>